<p><strong>Hi there,</strong></p>
  
<p>We received a request to sign you in to The Social Edge using this email address. If you want to sign in with your account, click the link below.</p>
<p>If you did not request this link, you can safely ignore this email.</p>

<a href="{{ route('user.verify', $token) }}" style=" grid-column-gap: 16px; grid-row-gap: 16px; color: #fff; text-align: center; cursor: pointer; background-color: #000; border-radius: 4px; grid-template-rows: auto; grid-template-columns: auto 1fr; grid-auto-columns: 1fr; padding: 0.75rem 1.5rem; text-decoration: none; transition: all .2s; display: inline-block; box-shadow: 0 2px 5px rgba(0, 0, 0, .05); ">Process to Sign in</a>