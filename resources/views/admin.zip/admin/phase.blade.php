@extends('layout.main')
@section('title','Phase')
@section('main-container')


<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->

<div class="content-page">
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title">@if(isset($phase_edit->id)) Edit Phases @else Phases @endif</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">

                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
    
@endif
                            <h4 class="mb-3 header-title mt-0">Add New Phase</h4>
                            <form action="{{ isset($phase_edit->id) ? '/admin/edit_phase/' . $phase_edit->id : '' }}"
                                method="post">
                                @csrf
                                @if(isset($phase_edit->id))
                                @method('PATCH')
                                @endif
                                <div class="row">
                                    <div class="col-6">
                                        <label class="form-label" for="">Enter Phase Name</label>
                                        <input type="text" class="form-control" id="" placeholder="Enter Phase name"
                                            name="name"
                                            value="{{ old('name', isset($phase_edit->id) ? $phase_edit->name : '') }}" />
                                        @if ($errors->has('name'))
                                        <span class="text-danger">{{ $errors->first('name') }}</span>
                                        @endif
                                    </div>

                                    <!-- <div class="col-2">
                                        <label class="form-label" for="">&nbsp;</label>
                                        <button type="submit"
                                            class="btn btn-primary btn-dark form-control">@if(isset($phase_edit->id))
                                            Edit @else Add @endif</button>
                                    </div> -->
                                </div>
                                <div class="row my-3">
                                    <div class="col-6">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Release Option</th>
                                                    <th scope="col">Release Date</th>

                                                </tr>
                                            </thead>
                                            <?php $id = 1 ?>
                                            @foreach($membership as $key=>$m_ship)
                                            <tbody>
                                                <tr>
                                                    <th scope="row">{{$id++}}</th>
                                                    <td>{{$m_ship->	membership_type}} <input type="hidden"
                                                            name="membership_id[]" value="{{$m_ship->id}}"> </td>
                                                            <td> <input type="datetime-local" class="form-control datetimepicker" id="date"
                                                            name="release_date[]" value="{{$m_ship->release_date}}"> 
                                                            @if($key == 0)
                                                            <div class="pt-2">
                                                            <input type="checkbox" id="apply_to_all">
                                                            <label for="apply_to_all">Same for all</label></div>
                                                             @endif

                                                        </td>

                                                </tr>

                                            </tbody>
                                            @endforeach
                                        </table>
                                    </div>
                                </div>
                                <div class="row my-3">
                                    <div class="col-6">
                                    <label class="form-label" for="">&nbsp;</label>
                                        <button type="submit"
                                            class="btn btn-primary btn-dark form-control">@if(isset($phase_edit->id))
                                            Edit @else Add @endif</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="mb-3 header-title mt-0">All Phases</h4>
                            <table id="tables" class="table table-striped dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th width="20">Sr. No.</th>
                                        <th>Phase Name</th>
                                        <th width="80">Action</th>
                                    </tr>
                                </thead>



                            </table>

                        </div> <!-- end card body-->
                    </div> <!-- end card -->
                </div><!-- end col-->
            </div>


        </div> <!-- container -->

    </div> <!-- content -->

    @endsection
    @section('auth-footer')
    <script>
    $(function() {
        var table = $('#tables').DataTable({
            processing: true,
            serverSide: true,
            language: {
                paginate: {
                    previous: "<i class='uil uil-angle-left'>",
                    next: "<i class='uil uil-angle-right'>"
                }
            },
            drawCallback: function() {
                $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
            },
            "destroy": true,
            ajax: "{{ url('admin/phase/{id}') }}",
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'name',

                },
                {
                    data: 'action',
                },

            ]
        });


    });
    $(document).ready(function(){
    $("#apply_to_all").click(function() {
        if ($("#apply_to_all").is(':checked')) {
            var date = $("input[name='release_date[]']").val();
            $("input[name='release_date[]']").val(date);
        }
    });
});
$('#date').on('change', function() {
    document.getElementById("apply_to_all").checked = false;
});
    </script>
    @endsection